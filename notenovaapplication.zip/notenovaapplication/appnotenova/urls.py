from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('breaks/', views.break_dashboard, name='break_dashboard'),
    path('start-break/', views.start_break, name='start_break'),
    path('end-break/', views.end_break, name='end_break'),
    path('case-dashboard/', views.case_dashboard, name='case_dashboard'),
    path('api/case-stats/', views.case_stats_api, name='case-stats-api'),
    path('api/create-case/', views.create_case, name='create-case'),
    path('links/', views.links_dashboard, name='links_dashboard'),
]
 