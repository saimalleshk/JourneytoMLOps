from django.db import models
from django.utils import timezone
from ckeditor.fields import RichTextField
from django.db.models import Sum
from django.db.models.functions import Extract


# models.py
'''
class TargetTime(models.Model):
    queue_type = models.CharField(max_length=100)  # e.g., 'chatqueue'
    target_minutes = models.FloatField()
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.queue_type} - {self.target_minutes} minutes"
'''

'''
class TargetTime(models.Model):
    queue_type = models.CharField(max_length=100)
    target_minutes = models.FloatField()
    is_active = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)  # Add this field to track last update

    def save(self, *args, **kwargs):
        # If this instance is being set as active
        if self.is_active:
            # Set this as the most recent active queue type
            self.updated_at = timezone.now()
        super(TargetTime, self).save(*args, **kwargs)

    def __str__(self):
        return self.queue_type

    class Meta:
        ordering = ['-updated_at']  # Order by most recent first

    @classmethod
    def get_default_queue(cls):
        return cls.objects.filter(is_active=True).order_by('-updated_at').first()
'''


# models.py
class TargetTime(models.Model):
    queue_type = models.CharField(max_length=100)
    target_minutes = models.FloatField()
    is_active = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.queue_type

    class Meta:
        ordering = ['-updated_at']

    @classmethod
    def get_active_queues(cls):
        return cls.objects.filter(is_active=True)

    @classmethod
    def get_default_queue(cls):
        active_queues = cls.get_active_queues()
        if active_queues.count() == 1:
            return active_queues.first()
        return None


class Case(models.Model):
    case_id = models.CharField(max_length=50, unique=True)
    assigned_at = models.DateTimeField()
    solved_at = models.DateTimeField(null=True, blank=True)
    annotations = models.TextField(blank=True)
    queue_type = models.ForeignKey(TargetTime, on_delete=models.SET_NULL, null=True, verbose_name='Queue Type')

    def get_formatted_time(self):
        if self.assigned_at and self.solved_at and self.queue_type:
            time_diff = self.solved_at - self.assigned_at
            total_seconds = time_diff.total_seconds()  # Keep as float
            minutes = int(total_seconds // 60)
            seconds = total_seconds % 60  # Keep decimal places
            
            color = 'red' if (total_seconds/60) > self.queue_type.target_minutes else 'green'
            
            if minutes > 0:
                time_str = f"{minutes}m {seconds:.2f}s"
            else:
                time_str = f"{seconds:.2f}s"
                
            return format_html('<span style="color: {};">{}</span>', color, time_str)
        return "N/A"

    def __str__(self):
        return self.case_id



class Point(models.Model):
    case = models.ForeignKey(Case, related_name='points', on_delete=models.CASCADE)
    key = models.CharField(max_length=50)
    value = models.TextField()

    def __str__(self):
        return f"{self.case.case_id} - {self.key}"


class TimeTracker(models.Model):
    BREAK_CHOICES = [
        ('break1', 'Break 1'),
        ('break2', 'Break 2'),
        ('lunch', 'Lunch'),
        ('training', 'Training'),
        ('meeting', 'Meeting'),
        ('dryque', 'DryQue'),
    ]

    AUX_CHOICES = [
        ('timeout', 'TimeOut'),
        ('Other', 'Other'),
        ('training', 'Training'),
        ('Mentoring', 'DEP'),
        ('DryQue', 'DryQue'),

    ]

    break_type = models.CharField(max_length=20, choices=BREAK_CHOICES)
    aux_used = models.CharField(max_length=20, choices=AUX_CHOICES)
    in_time = models.DateTimeField()
    out_time = models.DateTimeField(null=True, blank=True)
    
    @property
    def total_time(self):
        if self.out_time:
            duration = self.out_time - self.in_time
            return round(duration.total_seconds() / 60)
        return None

    def __str__(self):
        return f"{self.break_type} - {self.in_time}"


class NewsEntry(models.Model):
    headline = models.CharField(max_length=200)
    paragraph = RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.headline




class Link(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    link = models.URLField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']
