from django.contrib import admin
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from import_export import resources, fields
from import_export.admin import ImportExportModelAdmin
from import_export.widgets import ForeignKeyWidget, ManyToManyWidget
from django.db.models import Avg, F, ExpressionWrapper, fields, Sum
from django.utils import timezone
from .models import Case, Point, TimeTracker, TargetTime  
import os
from .models import NewsEntry
from .forms import NewsEntryAdminForm  
from django.http import HttpResponseRedirect
from django.http import HttpResponse 
import requests
from rangefilter.filters import DateRangeFilter, DateTimeRangeFilter
import json
from django.db.models import Sum
from django.db.models.functions import Extract
from django.core.mail import send_mail
from import_export.resources import ModelResource




@admin.register(TargetTime)
class TargetTimeAdmin(admin.ModelAdmin):
    list_display = ('queue_type', 'target_minutes', 'is_active', 'updated_at')
    list_editable = ('target_minutes', 'is_active')
    readonly_fields = ('updated_at',)




class PointInline(admin.TabularInline):
    model = Point
    extra = 1
    show_change_link = True


'''
@admin.register(Case)
class CaseAdmin(admin.ModelAdmin):
    list_display = ('case_id', 'queue_type', 'assigned_at', 'get_points', 'solved_at', 'get_annotations', 'get_total_time')
    list_display_links = ('case_id',)
    search_fields = ('case_id', 'annotations', 'points__key', 'points__value')
    list_filter = (
        'queue_type',
        ('assigned_at',DateRangeFilter),
        ('solved_at',DateRangeFilter),
    )
    inlines = [PointInline]
    change_list_template = "admin/appnotenova/case/change_list.html"

    def get_points(self, obj):
        points = obj.points.all()
        formatted_points = [
            format_html('<strong>{}:</strong> {}', p.key, p.value)
            for p in points
        ]
        return format_html('<div style="max-width:300px; font-size:14px; white-space:pre-wrap;">{}</div>',
                           mark_safe('<br>'.join(formatted_points)))
    get_points.short_description = 'Points'

    def get_annotations(self, obj):
        return format_html('<div style="max-width:500px; white-space:pre-wrap;">{}</div>', obj.annotations)
    get_annotations.short_description = 'Annotations'

    def get_total_time(self, obj):
        if obj.assigned_at and obj.solved_at and obj.queue_type:
            total_minutes = (obj.solved_at - obj.assigned_at).total_seconds() / 60
            target_minutes = obj.queue_type.target_minutes
            color = 'red' if total_minutes > target_minutes else 'green'
            return format_html('<span style="color: {};">{} minutes (Target: {})</span>', 
                             color, round(total_minutes, 2), target_minutes)
        return "N/A"
    get_total_time.short_description = 'Total Time'

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request, extra_context)
        
        # Get date range from request
        assigned_at_range = request.GET.get('assigned_at__range__gte'), request.GET.get('assigned_at__range__lte')
        
        # Base queryset with date filter
        if assigned_at_range[0] and assigned_at_range[1]:
            daily_cases = Case.objects.filter(
                assigned_at__date__gte=assigned_at_range[0],
                assigned_at__date__lte=assigned_at_range[1],
                solved_at__isnull=False
            )
            date_display = f"{assigned_at_range[0]} to {assigned_at_range[1]}"
        else:
            today = timezone.now().date()
            daily_cases = Case.objects.filter(
                assigned_at__date=today,
                solved_at__isnull=False
            )
            date_display = "Today"

        # Calculate combined stats for all queues
        total_target_time = 0
        total_actual_time = 0
        total_cases = 0

        for case in daily_cases:
            if case.queue_type and case.queue_type.is_active:
                total_cases += 1
                # Add target time for this case
                total_target_time += case.queue_type.target_minutes
                # Add actual time for this case
                actual_minutes = (case.solved_at - case.assigned_at).total_seconds() / 60
                total_actual_time += actual_minutes

        if total_cases > 0:
            total_difference = total_target_time - total_actual_time
            aht_variance = total_difference * 0.1

            stats = {
                'target_total': "{:.2f}".format(total_target_time),
                'actual_total': "{:.2f}".format(total_actual_time),
                'difference': "{:.2f}".format(total_difference),
                'aht_variance': "{:.2f}".format(aht_variance),
                'case_count': total_cases
            }
        else:
            stats = {
                'target_total': "0.00",
                'actual_total': "0.00",
                'difference': "0.00",
                'aht_variance': "0.00",
                'case_count': 0
            }

        if hasattr(response, 'context_data'):
            response.context_data.update({
                'stats': stats,
                'date_range': date_display,
                'show_clocks': True,  # Flag to show clocks

            })
        
        return response

    

    class Media:
        css = {
            'all': ('admin/css/custom_admin.css',)
        }
'''



class PointInline(admin.TabularInline):
    model = Point
    extra = 1

class CaseResource(ModelResource):
    class Meta:
        model = Case
        fields = (
            'id', 
            'case_id', 
            'queue_type', 
            'assigned_at', 
            'solved_at', 
            'annotations'
        )
        export_order = fields

    def dehydrate_queue_type(self, obj):
        return str(obj.queue_type) if obj.queue_type else ''

    def export(self, queryset=None, *args, **kwargs):
        """
        Exports only the provided queryset (selected items)
        """
        if not queryset:
            queryset = self.get_queryset()
        
        data = super().export(queryset, *args, **kwargs)
        
        data.append_col(
            [self.get_total_time(obj) for obj in queryset],
            header='Total Time (Minutes)'
        )
        
        return data

    def get_total_time(self, obj):
        if obj.assigned_at and obj.solved_at:
            total_minutes = (obj.solved_at - obj.assigned_at).total_seconds() / 60
            return round(total_minutes, 2)
        return None

@admin.register(Case)
class CaseAdmin(ImportExportModelAdmin):
    resource_class = CaseResource
    
    list_display = ('case_id', 'queue_type', 'assigned_at', 'get_points', 'solved_at', 'get_annotations', 'get_total_time')
    list_display_links = ('case_id',)
    search_fields = ('case_id', 'annotations', 'points__key', 'points__value')
    list_filter = (
        'queue_type',
        ('assigned_at',DateRangeFilter),
        ('solved_at',DateRangeFilter),
    )
    inlines = [PointInline]
    change_list_template = "admin/appnotenova/case/change_list.html"
    list_select_related = True
    list_per_page = 20
    actions = ['export_selected']

    def get_points(self, obj):
        points = obj.points.all()
        formatted_points = [
            format_html('<strong>{}:</strong> {}', p.key, p.value)
            for p in points
        ]
        return format_html('<div style="max-width:300px; font-size:14px; white-space:pre-wrap;">{}</div>',
                           mark_safe('<br>'.join(formatted_points)))
    get_points.short_description = 'Points'

    def get_annotations(self, obj):
        return format_html('<div style="max-width:500px; white-space:pre-wrap;">{}</div>', obj.annotations)
    get_annotations.short_description = 'Annotations'

    def get_total_time(self, obj):
        if obj.assigned_at and obj.solved_at and obj.queue_type:
            time_diff = obj.solved_at - obj.assigned_at
            total_seconds = time_diff.total_seconds()
            
            # Convert to minutes and seconds
            minutes = int(total_seconds // 60)
            remaining_seconds = total_seconds % 60
            
            # Format strings first
            if minutes > 0:
                time_str = f"{minutes}m {remaining_seconds:.2f}s"
            else:
                time_str = f"{remaining_seconds:.2f}s"
            
            # Calculate total minutes for comparison
            total_minutes = total_seconds / 60
            target_minutes = obj.queue_type.target_minutes
            color = 'red' if total_minutes > target_minutes else 'green'
            
            # Format the decimal minutes
            minutes_str = "{:.2f}".format(total_minutes)
            
            return format_html(
                '<div style="color: {};">'
                '{}<br>'
                '<small>({} minutes)</small><br>'
                '<small>Target: {} min</small>'
                '</div>', 
                color,
                time_str,
                minutes_str,
                target_minutes
            )
        return "N/A"
    get_total_time.short_description = 'Total Time'

    def export_selected(self, request, queryset):
        """
        Custom action to export only selected items
        """
        resource = self.resource_class()
        dataset = resource.export(queryset)
        format = request.POST.get('file_format', 'csv')
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="selected_cases.csv"'
        response.write(dataset.csv)
        return response
    export_selected.short_description = "Export Selected Cases"

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request, extra_context)
        
        assigned_at_range = request.GET.get('assigned_at__range__gte'), request.GET.get('assigned_at__range__lte')
        
        if assigned_at_range[0] and assigned_at_range[1]:
            daily_cases = Case.objects.filter(
                assigned_at__date__gte=assigned_at_range[0],
                assigned_at__date__lte=assigned_at_range[1],
                solved_at__isnull=False
            )
            date_display = f"{assigned_at_range[0]} to {assigned_at_range[1]}"
        else:
            today = timezone.now().date()
            daily_cases = Case.objects.filter(
                assigned_at__date=today,
                solved_at__isnull=False
            )
            date_display = "Today"

        total_target_time = 0
        total_actual_time = 0
        total_cases = 0

        for case in daily_cases:
            if case.queue_type and case.queue_type.is_active:
                total_cases += 1
                total_target_time += case.queue_type.target_minutes
                actual_minutes = (case.solved_at - case.assigned_at).total_seconds() / 60
                total_actual_time += actual_minutes

        if total_cases > 0:
            total_difference = total_target_time - total_actual_time
            aht_variance = total_difference * 0.1

            stats = {
                'target_total': "{:.2f}".format(total_target_time),
                'actual_total': "{:.2f}".format(total_actual_time),
                'difference': "{:.2f}".format(total_difference),
                'aht_variance': "{:.2f}".format(aht_variance),
                'case_count': total_cases
            }
        else:
            stats = {
                'target_total': "0.00",
                'actual_total': "0.00",
                'difference': "0.00",
                'aht_variance': "0.00",
                'case_count': 0
            }

        if hasattr(response, 'context_data'):
            response.context_data.update({
                'stats': stats,
                'date_range': date_display,
                'show_clocks': True,
            })
        
        return response

    class Media:
        css = {
            'all': ('admin/css/custom_admin.css',)
        }


@admin.register(Point)
class PointAdmin(admin.ModelAdmin):
    list_display = ('case', 'key', 'value')
    list_display_links = ('case', 'key')
    search_fields = ('case__case_id', 'key', 'value')
    list_filter = ('key',)

@admin.register(TimeTracker)
class TimeTrackerAdmin(admin.ModelAdmin):
    list_display = ('break_type', 'aux_used', 'in_time', 'out_time', 'get_total_time')
    list_filter = ('break_type', 'aux_used', 'in_time', 'out_time')
    search_fields = ('break_type',)

    def get_total_time(self, obj):
        if obj.out_time and obj.in_time:
            duration = obj.out_time - obj.in_time
            minutes = duration.total_seconds() / 60
            return f"{int(minutes)} minutes"
        return "N/A"
    get_total_time.short_description = 'Total Time'





# --------------------------------------- editing on 17/01/2025 ------------------
from django.contrib import admin, messages
from django.http import HttpResponseRedirect
from .models import NewsEntry
import requests
import json
import html2text  # Change this import

@admin.register(NewsEntry)
class NewsEntryAdmin(admin.ModelAdmin):
    list_display = ('headline', 'created_at')
    search_fields = ('headline', 'paragraph')
    readonly_fields = ('created_at',)

    def send_to_chime(self, obj):
        webhook_url = ""
        formatted_date = obj.created_at.strftime('%Y-%m-%d')
        
        # Validate content
        if not obj.headline or not obj.paragraph:
            return False, "Headline and content are required!"
        
        # Configure html2text
        h = html2text.HTML2Text()
        h.body_width = 0
        h.unicode_snob = True
        h.tables = True
        
        # Convert HTML to Markdown
        markdown_content = h.handle(obj.paragraph)
        
        message = {
            "Content": f"/md # {obj.headline}\n\n{markdown_content} \n\n*Posted on: {formatted_date}*\n\n@All "
        }



        try:
            response = requests.post(
                webhook_url,
                data=json.dumps(message),
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            return True, "Message sent successfully!"
        except Exception as e:
            return False, f"Error sending to Chime: {str(e)}"

    def response_change(self, request, obj):
        if "_send_chime_only" in request.POST:
            success, message = self.send_to_chime(obj)
            if success:
                self.message_user(request, message, level=messages.SUCCESS)
            else:
                self.message_user(request, message, level=messages.ERROR)
            return HttpResponseRedirect(".")
        
        if "_save_and_chime" in request.POST:
            success, message = self.send_to_chime(obj)
            if success:
                self.message_user(request, "Entry saved and sent to Chime successfully!")
            else:
                self.message_user(request, f"Entry saved but failed to send to Chime: {message}")
            return HttpResponseRedirect(".")
        return super().response_change(request, obj)

    def response_add(self, request, obj, post_url_continue=None):
        if "_send_chime_only" in request.POST:
            success, message = self.send_to_chime(obj)
            if success:
                self.message_user(request, message, level=messages.SUCCESS)
            else:
                self.message_user(request, message, level=messages.ERROR)
            return HttpResponseRedirect(".")
            
        if "_save_and_chime" in request.POST:
            success, message = self.send_to_chime(obj)
            if success:
                self.message_user(request, "Entry saved and sent to Chime successfully!")
            else:
                self.message_user(request, f"Entry saved but failed to send to Chime: {message}")
            return HttpResponseRedirect(".")
        return super().response_add(request, obj, post_url_continue)


# For links and descriptions

from django.contrib import admin
from .models import Link

@admin.register(Link)
class LinkAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'link', 'created_at', 'updated_at')
    search_fields = ('name', 'description')
    list_filter = ('created_at', 'updated_at')
