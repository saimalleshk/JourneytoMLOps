# your_app/management/commands/send_daily_news.py

from django.core.management.base import BaseCommand
from your_app.models import NewsEntry
import html2text
import requests
import json
import logging

logging.basicConfig(
    filename='news_webhook_logs.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class Command(BaseCommand):
    help = 'Send news entry to Chime webhook at 6 PM'

    def handle(self, *args, **kwargs):
        try:
            webhook_url = "https://hooks.chime.aws/incomingwebhooks/2549c7fa-6e20-4ddb-b5a7-26677d2ebd8a?token=RVZSZjFvUWZ8MXxpRy1PWnlGeldOZkFLSEZjQzlXMmwzelVpZzF1RmpnMk1BNXFJSENOOFdj"  # Replace with your webhook URL
            
            # Get the first/only entry
            entry = NewsEntry.objects.first()  # or use .get(headline='Reminder') if specific

            if not entry:
                logging.info("No news entry found")
                return

            # Configure html2text
            h = html2text.HTML2Text()
            h.body_width = 0
            h.unicode_snob = True
            h.tables = True

            # Prepare and send message
            markdown_content = h.handle(entry.paragraph)
            
            message = {
                "Content": f"/md ### 📢 {entry.headline} 📢\n\n{markdown_content}\n\n---\n_Daily Reminder_"
            }


            response = requests.post(
                webhook_url,
                data=json.dumps(message),
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            logging.info(f"Successfully sent message: {entry.headline}")

        except Exception as e:
            logging.error(f"Error sending message: {str(e)}")
