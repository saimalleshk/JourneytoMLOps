from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request, 'appnotenova/home.html')

#-----------------Added for breaks dashboard --------
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from datetime import datetime, time
from .models import TimeTracker, NewsEntry  
import json

def break_dashboard(request):
    # Get today's date with timezone awareness
    today = timezone.localtime(timezone.now()).date()
    
    # Get today's date range (from midnight to 11:59:59 PM)
    today_start = timezone.make_aware(datetime.combine(today, time.min))
    today_end = timezone.make_aware(datetime.combine(today, time.max))
    
    # Filter breaks for today only
    breaks = TimeTracker.objects.filter(
        in_time__range=(today_start, today_end)
    ).order_by('-in_time')
    
    # Calculate duration for each break
    for break_item in breaks:
        if break_item.out_time:
            duration = break_item.out_time - break_item.in_time
            minutes = duration.total_seconds() / 60
            if minutes >= 60:
                hours = int(minutes // 60)
                remaining_minutes = int(minutes % 60)
                break_item.duration = f"{hours}h {remaining_minutes}m"
            else:
                break_item.duration = f"{int(minutes)}m"
        else:
            break_item.duration = "Ongoing"
    
    context = {
        'breaks': breaks,
        'today': today,
    }
    
    return render(request, 'appnotenova/break_dashboard.html', context)

@csrf_exempt
def start_break(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Check for ongoing breaks
            ongoing_break = TimeTracker.objects.filter(out_time__isnull=True).first()
            if ongoing_break:
                return JsonResponse({
                    'status': 'error',
                    'message': 'There is already an active break'
                }, status=400)
            
            # Create new break
            new_break = TimeTracker.objects.create(
                break_type=data.get('break_type'),
                aux_used=data.get('aux_used'),
                in_time=timezone.now()
            )
            
            print(f"New break created: {new_break.break_type} at {new_break.in_time}")
            
            return JsonResponse({'status': 'success'})
            
        except Exception as e:
            print(f"Error starting break: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid method'}, status=405)

@csrf_exempt
def end_break(request):
    if request.method == 'POST':
        try:
            # Find the active break
            active_break = TimeTracker.objects.filter(
                out_time__isnull=True
            ).order_by('-in_time').first()
            
            if active_break:
                # Set the end time
                active_break.out_time = timezone.now()
                active_break.save()
                
                # Calculate duration for display
                duration = active_break.out_time - active_break.in_time
                minutes = duration.total_seconds() / 60
                duration_display = f"{int(minutes)} minutes"
                
                print(f"Break ended: {active_break.break_type} - Duration: {duration_display}")
                
                return JsonResponse({
                    'status': 'success',
                    'duration': duration_display
                })
            
            return JsonResponse({
                'status': 'error',
                'message': 'No active break found'
            }, status=404)
            
        except Exception as e:
            print(f"Error ending break: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid method'}, status=405)



# ---------------- Added for Cases Dashboard --------------------------


# notenova/appnotenova/views.py
# notenova/appnotenova/views.py

from django.shortcuts import render
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.utils import timezone
from .models import Case, TargetTime
from django.db.models import Q

from django.utils import timezone
from django.db.models import Q

'''
# views.py
def case_dashboard(request):
    # Get target times and default queue
    target_times = TargetTime.objects.filter(is_active=True)
    default_queue = TargetTime.get_default_queue()  # Add this line
    
    # Get search query
    search_query = request.GET.get('search', '')
    
    # Base queryset
    cases = Case.objects.select_related('queue_type')

    # Apply search if query exists
    if search_query:
        cases = cases.filter(
            Q(case_id__icontains=search_query) |
            Q(queue_type__queue_type__icontains=search_query) |
            Q(annotations__icontains=search_query)
        ).distinct()
    else:
        # If no search, show today's cases
        today = timezone.now().date()
        cases = cases.filter(assigned_at__date=today)

    # Apply solved filter
    cases = cases.filter(solved_at__isnull=False)

    # Calculate stats
    stats = calculate_stats(cases)
    
    # Prepare case data
    cases_data = prepare_case_data(cases)

    context = {
        'target_times': target_times,
        'default_queue': default_queue,  # Add this line
        'cases': cases_data,
        'stats': stats,
        'search_query': search_query,
    }

    return render(request, 'appnotenova/case_dashboard.html', context)
'''


def case_dashboard(request):
    # Get active queue times
    active_queues = TargetTime.objects.filter(is_active=True)
    
    # Determine if we show dropdown and get default queue
    show_queue_dropdown = active_queues.count() > 1
    default_queue = active_queues.first() if active_queues.count() == 1 else None
    
    # Get search query
    search_query = request.GET.get('search', '')
    
    # Base queryset
    cases = Case.objects.select_related('queue_type')

    # Apply search if query exists
    if search_query:
        cases = cases.filter(
            Q(case_id__icontains=search_query) |
            Q(queue_type__queue_type__icontains=search_query) |
            Q(annotations__icontains=search_query)
        ).distinct()
    else:
        # If no search, show today's cases
        today = timezone.now().date()
        cases = cases.filter(assigned_at__date=today)

    # Apply solved filter
    cases = cases.filter(solved_at__isnull=False)

    # Calculate stats
    stats = calculate_stats(cases)
    
    # Prepare case data
    cases_data = prepare_case_data(cases)

    context = {
        'target_times': active_queues,
        'default_queue': default_queue,
        'show_queue_dropdown': show_queue_dropdown,  # Add this line
        'cases': cases_data,
        'stats': stats,
        'search_query': search_query,
    }

    return render(request, 'appnotenova/case_dashboard.html', context)



def calculate_stats(queryset):
    cases_by_queue = {}
    total_target_time = 0
    total_actual_time = 0
    total_cases = 0
    total_variance = 0

    for case in queryset:
        if case.queue_type:
            total_cases += 1
            target_time = case.queue_type.target_minutes
            actual_minutes = (case.solved_at - case.assigned_at).total_seconds() / 60
            
            # Calculate individual case variance
            if target_time > 0:
                case_variance = ((actual_minutes - target_time) / target_time) * 100
                total_variance += case_variance
            
            total_target_time += target_time
            total_actual_time += actual_minutes

            # Group cases by queue type for detailed analysis
            queue_id = case.queue_type.id
            if queue_id not in cases_by_queue:
                cases_by_queue[queue_id] = {
                    'count': 0,
                    'total_variance': 0,
                }
            cases_by_queue[queue_id]['count'] += 1
            cases_by_queue[queue_id]['total_variance'] += case_variance if target_time > 0 else 0

    # Calculate total difference and average AHT variance
    total_difference = total_target_time - total_actual_time
    aht_variance = total_difference * 0.1 if total_cases > 0 else 0


    return {
        'target_total': "{:.2f}".format(total_target_time),
        'actual_total': "{:.2f}".format(total_actual_time),
        'difference': "{:.2f}".format(total_difference),
        'aht_variance': "{:.2f}".format(aht_variance), 
        'case_count': total_cases,
        'queue_stats': cases_by_queue
    }

def prepare_case_data(cases):
    cases_data = []
    for case in cases:
        if case.assigned_at and case.solved_at:
            time_diff = case.solved_at - case.assigned_at
            total_seconds = time_diff.total_seconds()
            minutes = int(total_seconds // 60)
            seconds = total_seconds % 60
            
            # Format time string
            if minutes > 0:
                time_str = f"{minutes}m {seconds:.2f}s"
            else:
                time_str = f"{seconds:.2f}s"
            
            # Color coding
            color = 'red' if (total_seconds/60) > case.queue_type.target_minutes else 'green'
            formatted_time = f'<span style="color: {color};">{time_str}</span>'
        else:
            formatted_time = 'N/A'

        cases_data.append({
            'case_id': case.case_id,
            'queue_type': case.queue_type.queue_type if case.queue_type else 'N/A',
            'assigned_at': case.assigned_at,
            'solved_at': case.solved_at,
            'total_time': formatted_time,  # Changed this line
            'annotations': case.annotations
        })
    return cases_data


def case_stats_api(request):
    queue_type = request.GET.get('queue_type')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    search_query = request.GET.get('search', '')

    # Build query
    query = Q(solved_at__isnull=False)
    if queue_type:
        query &= Q(queue_type_id=queue_type)
    if start_date:
        query &= Q(assigned_at__date__gte=start_date)
    if end_date:
        query &= Q(assigned_at__date__lte=end_date)
    
    # Add search query
    if search_query:
        query &= (
            Q(case_id__icontains=search_query) |
            Q(queue_type__queue_type__icontains=search_query) |
            Q(annotations__icontains=search_query)
        )

    cases = Case.objects.filter(query).select_related('queue_type').order_by('-solved_at')  # Add order_by here

    
    # Calculate stats
    stats = calculate_stats(cases)
    
    # Prepare cases data
    cases_data = prepare_case_data(cases)
    
    # Render cases table HTML
    cases_html = render_to_string(
        'appnotenova/case_table_rows.html',
        {'cases': cases_data}
    )
    
    # Add cases HTML to response
    stats['cases_html'] = cases_html
    
    return JsonResponse(stats)

#------------ For Handling Case Creation -------------

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_protect
import json

@csrf_protect
def create_case(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Create new case
            case = Case.objects.create(
                case_id=data['case_id'],
                queue_type_id=data['queue_type'],
                assigned_at=data['assigned_at'],
                solved_at=data['solved_at'] if data['solved_at'] else None,
                annotations=data['annotations']
            )
            
            return JsonResponse({
                'success': True,
                'message': 'Case created successfully',
                'case_id': case.case_id
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=400)
            
    return JsonResponse({
        'success': False,
        'error': 'Invalid request method'
    }, status=405)


# For Links and Descriptions

from django.shortcuts import render
from .models import Link
from django.db.models import Q

def links_dashboard(request):
    query = request.GET.get('q', '')
    if query:
        links = Link.objects.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query)
        )
    else:
        links = Link.objects.all()
    
    return render(request, 'appnotenova/links_dashboard.html', {
        'links': links,
        'query': query,
    })
