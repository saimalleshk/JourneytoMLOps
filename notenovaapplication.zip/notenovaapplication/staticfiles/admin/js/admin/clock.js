function updateClocks() {
    const clocks = document.querySelectorAll('.clock');
    
    clocks.forEach(clock => {
        const timezone = clock.dataset.timezone;
        const now = new Date();
        const options = {
            timeZone: timezone,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        };
        clock.querySelector('.time').textContent = now.toLocaleTimeString('en-US', options);
        clock.querySelector('.date').textContent = now.toLocaleDateString('en-US', { timeZone: timezone });
    });
}

function updateTimezone(selectElement, clockIndex) {
    const clock = document.querySelectorAll('.clock')[clockIndex];
    clock.dataset.timezone = selectElement.value;
    localStorage.setItem(`clock${clockIndex}Timezone`, selectElement.value);
}

document.addEventListener('DOMContentLoaded', function() {
    // Load saved timezones from localStorage
    const clocks = document.querySelectorAll('.clock');
    clocks.forEach((clock, index) => {
        const savedTimezone = localStorage.getItem(`clock${index}Timezone`);
        if (savedTimezone) {
            clock.dataset.timezone = savedTimezone;
            const select = clock.querySelector('select');
            select.value = savedTimezone;
        }
    });

    // Update clocks every second
    updateClocks();
    setInterval(updateClocks, 1000);
});
