NoteNova Setup Instructions:
1. Install Python 3.x from python.org if not already installed
2. Run initial_setup.bat and follow the prompts
3. For future use, just run run_server.bat to start the server

Note: If you encounter any errors, make sure Python is added to your system's PATH variable.
