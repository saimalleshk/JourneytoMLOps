function updateClocks() {
    const clocks = document.querySelectorAll('.clock');
    
    clocks.forEach(clock => {
        const timezone = clock.dataset.timezone;
        const now = new Date();
        
        try {
            const options = {
                timeZone: timezone,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true
            };
            
            const dateOptions = {
                timeZone: timezone,
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            };

            clock.querySelector('.time').textContent = now.toLocaleTimeString('en-US', options);
            clock.querySelector('.date').textContent = now.toLocaleDateString('en-US', dateOptions);
        } catch (e) {
            console.error('Error updating clock:', e);
        }
    });
}

function updateTimezone(selectElement, clockIndex) {
    const clock = document.querySelectorAll('.clock')[clockIndex];
    clock.dataset.timezone = selectElement.value;
    localStorage.setItem(`clock${clockIndex}Timezone`, selectElement.value);
    updateClocks();  // Update immediately after changing timezone
}

// Initialize clocks when the document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Load saved timezones
    const clocks = document.querySelectorAll('.clock');
    clocks.forEach((clock, index) => {
        const savedTimezone = localStorage.getItem(`clock${index}Timezone`);
        if (savedTimezone) {
            clock.dataset.timezone = savedTimezone;
            const select = clock.querySelector('select');
            if (select) {
                select.value = savedTimezone;
            }
        }
    });

    // Start the clock updates
    updateClocks();
    setInterval(updateClocks, 1000);
});
