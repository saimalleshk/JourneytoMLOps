@echo off
TITLE NoteNova Django Server

:: Activate virtual environment
call "%~dp0djangoenv\Scripts\activate.bat"

:: Run Django server
python manage.py runserver

pause
