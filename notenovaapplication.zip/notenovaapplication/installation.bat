@echo off
echo Starting setup process...

:: Set project-specific variables
set PROJECT_NAME=notenova
set APP_NAME=appnotenova
set ENV_NAME=djangoenv

:: Change to the correct directory (if needed)
cd /d %~dp0

:: Remove existing database and migrations
echo Cleaning up existing files...
if exist "db.sqlite3" (
    del /f /q db.sqlite3
    echo Removed existing database
)
if exist "%APP_NAME%\migrations" (
    rmdir /s /q "%APP_NAME%\migrations"
    echo Removed existing migrations
)
mkdir "%APP_NAME%\migrations"
type nul > "%APP_NAME%\migrations\__init__.py"
echo Created new migrations folder

:: Check if virtual environment exists, if not create it
if not exist "%ENV_NAME%\Scripts\activate.bat" (
    echo Creating virtual environment...
    python -m venv %ENV_NAME%
)

:: Activate virtual environment
echo Activating virtual environment...
call %ENV_NAME%\Scripts\activate

:: Install/Upgrade pip
python -m pip install --upgrade pip

:: Install requirements from requirements.txt
echo Installing requirements...
pip install -r requirements.txt

:: Make and apply migrations
echo Creating migrations...
python manage.py makemigrations %APP_NAME%

echo Applying migrations...
python manage.py migrate

:: Create superuser
echo.
echo Creating superuser...
echo Please enter superuser credentials:
python manage.py createsuperuser

echo.
echo Setup complete!
echo.
echo To start the server, run: python manage.py runserver
echo Then visit: http://127.0.0.1:8000/admin/
echo.
pause